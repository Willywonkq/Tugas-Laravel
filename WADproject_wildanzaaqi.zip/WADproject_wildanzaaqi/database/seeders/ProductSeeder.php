<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductSeeder extends Seeder
{
    public function run()
    {
        Product::truncate();

        Product::create(['name' => 'Laptop Acer', 'stock' => 10, 'price' => 90000.00]);
        Product::create(['name' => 'Mouse Logitech', 'stock' => 50, 'price' => 150000.00]);
        Product::create(['name' => 'Monitor LG', 'stock' => 15, 'price' => 250000.00]);
    }
}
